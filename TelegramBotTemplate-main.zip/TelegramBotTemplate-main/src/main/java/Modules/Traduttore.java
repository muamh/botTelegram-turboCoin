package Modules;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URLEncoder;

public class Traduttore {

    public static String getTraduzione(String text) {
        try {
            System.out.println("entro inizio");
            String url = URLEncoder.encode(text, "UTF-8");
            System.out.println("encodato: " + url);
            // Ottieni il documento HTML dalla pagina web
            Document document = Jsoup.connect("https://translate.google.it/?hl=it&sl=auto&tl=it&text=" + url + "&op=translate").get();
            System.out.println("connessione avvenuta");
            System.out.println(document.toString());
            // Trova gli elementi con la classe "lRu31"
            Elements elementsWithClass = document.select("span.ryNqvb");
            System.out.println("preso elementi con classe ryNqvb");

            // Se esiste almeno un elemento con la classe "lRu31", restituisci il testo del primo elemento
            if (!elementsWithClass.isEmpty()) {
                System.out.println("non è vuoto");
                Element primoElemento = elementsWithClass.get(0);
                System.out.println("preso primo elemento");
                return primoElemento.text();
            } else {
                System.out.println("errore 1");
                return "Nessun elemento con classe ryNqvb trovato.";
            }
        } catch (IOException e) {
            System.out.println("errore 2");
            e.printStackTrace();
            return "Errore durante il recupero del testo.";
        }
    }

    // Puoi aggiungere altri metodi o costruttori secondo le tue esigenze
}
